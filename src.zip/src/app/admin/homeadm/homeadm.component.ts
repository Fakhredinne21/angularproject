import { Component } from '@angular/core';

@Component({
  selector: 'app-homeadm',
  templateUrl: './homeadm.component.html',
  styleUrls: ['./homeadm.component.css']
})
export class HomeadmComponent {

}
