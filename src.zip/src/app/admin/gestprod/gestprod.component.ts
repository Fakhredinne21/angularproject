import { identifierName } from '@angular/compiler';
import { Component } from '@angular/core';
import { CrudService } from 'src/app/services/crud.service';
import { Produit } from 'src/app/shared/models/produit';

@Component({
  selector: 'app-gestprod',
  templateUrl: './gestprod.component.html',
  styleUrls: ['./gestprod.component.css']
})
export class GestprodComponent {
  title = "PRODUITS" ;
  produits !:Produit[];
  produit!: Produit;

 details(p:Produit){
    this.produit=p;
   
  }
constructor(private productService: CrudService) {}
 
getProducts(): void {
      this.productService.getProducts()
      .subscribe(products => this.produits = products);
  
}
ngOnInit(): void {
      this.getProducts();
}

create(){
  const create=document.createElement('app-product-add');
  const app = document.querySelector('app-gestprod');
  const bod=app?.querySelector('body');
  bod?.appendChild(create);
}
}
