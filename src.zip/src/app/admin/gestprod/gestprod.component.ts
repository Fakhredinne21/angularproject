import { identifierName } from '@angular/compiler';
import { Component } from '@angular/core';
import { CrudService } from 'src/app/services/crud.service';
import { Produit } from 'src/app/shared/models/produit';

@Component({
  selector: 'app-gestprod',
  templateUrl: './gestprod.component.html',
  styleUrls: ['./gestprod.component.css']
})
export class GestprodComponent {
  title = "PRODUITS" ;
  produits !:Produit[];
  produit!: Produit;

 details(p:Produit){
    this.produit=p;
   
  }
constructor(private productService: CrudService) {}
 
getProducts(): void {
      this.productService.getProducts()
      .subscribe(products => this.produits = products);
  
}

deleteProduct(id:any):void{
 const res=confirm("Are You sure you want to delete?");
 if(res){
    this.productService.deleteProduct(id).subscribe(result =>{

    });
 }

}

ngOnInit(): void {
      this.getProducts();
}


}
