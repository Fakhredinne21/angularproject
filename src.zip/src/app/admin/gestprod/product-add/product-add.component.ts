import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,FormBuilder, AbstractControl } from '@angular/forms'; 
import { CrudService } from 'src/app/services/crud.service';
import { Produit } from 'src/app/shared/models/produit';

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.css']
})
export class ProductAddComponent implements OnInit{
    productAddForm!: FormGroup; 
    constructor(private fb:FormBuilder,private productService: CrudService) { } 
     ngOnInit(): void {
      this.productAddForm = this.fb.group({ 
        id:[''],
        nom: [''],
        image:[''],
        prix:[''],
        description:[''],
        categId:['']
      });
    } 
    
    addProducts():void{
      if (this.productAddForm.valid) {
        const formData: Produit = this.productAddForm.value;
      this.productService.addProduct(formData).subscribe(result => {
        // Handle add success
      });
    }
    }
    
    afficher(){
      alert("Name:"+this.productAddForm.controls['nameControl'].value+"\nPrix:"+this.productAddForm.controls['prixControl'].value+"\nCategorie:"+this.productAddForm.controls['categorieControl'].value);
    }
   
     
  
    
     
  
 
}
