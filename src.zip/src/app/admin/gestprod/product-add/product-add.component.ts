import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,FormBuilder, AbstractControl } from '@angular/forms'; 

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.css']
})
export class ProductAddComponent implements OnInit{
    productAddForm!: FormGroup; 
   
     ngOnInit(): void {
      this.productAddForm = this.fb.group({ 
        nameControl: [''],
        prixControl:[''],
        descriptionControl:[''],
        imageControl:[''],
        categorieControl:['']
      });
    } 
    constructor(private fb:FormBuilder) { } 
    afficher(){
      alert("Name:"+this.productAddForm.controls['nameControl'].value+"\nPrix:"+this.productAddForm.controls['prixControl'].value+"\nCategorie:"+this.productAddForm.controls['categorieControl'].value);
    }
   
     
  
    
     
  
 
}
