import { Component } from '@angular/core';
import { CrudOrdersService } from 'src/app/services/crud-orders.service';
import { CrudService } from 'src/app/services/crud.service';
import { Order } from 'src/app/shared/models/order';
import { Produit } from 'src/app/shared/models/produit';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent {
  title = "PRODUITS" ;
  orders !:Order[];
  order!: Order;

 details(p:Order){
    this.order=p;
   
  }
constructor(private orderService: CrudOrdersService) {}
 
getOrders(): void {
      this.orderService.getOrders()
      .subscribe(orders => this.orders = orders);
  
}

deleteOrder(id:any):void{
 const res=confirm("Are You sure you want to delete?");
 if(res){
    this.orderService.deleteOrder(id).subscribe(result =>{

    });
 }

}

ngOnInit(): void {
      this.getOrders();
}
}
