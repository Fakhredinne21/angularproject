import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';

import { HomeProductsComponent } from './home-products.component';
import { HomeProductDetailComponent } from './home-product-detail.component';


@NgModule({
  declarations: [
    HomeComponent,
    HomeProductsComponent,
    HomeProductDetailComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule
  ],
  exports: [
    HomeComponent
  ]
})
export class HomeModule { }
