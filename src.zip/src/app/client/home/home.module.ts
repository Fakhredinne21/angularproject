import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';

import { HomeProductsComponent } from './home-products.component';
import { HomeProductDetailComponent } from './home-product-detail.component';
import { AddorderComponent } from './addorder.component';
import { ListordersComponent } from './listorders.component';


@NgModule({
  declarations: [
    HomeComponent,
    HomeProductsComponent,
    HomeProductDetailComponent,
    AddorderComponent,
    ListordersComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule
  ],
  exports: [
    HomeComponent,
    AddorderComponent,
    ListordersComponent
  ]
})
export class HomeModule { }
