import { Component } from '@angular/core';
import { CrudOrdersService } from 'src/app/services/crud-orders.service';
import { Order } from 'src/app/shared/models/order';

@Component({
  selector: 'app-listorders',
  templateUrl: './listorders.component.html',
  styleUrls: ['./listorders.component.css']
})
export class ListordersComponent {
  title = "PRODUITS" ;
  orders !:Order[];
  order!: Order;

 details(p:Order){
    this.order=p;
   
  }
constructor(private orderService: CrudOrdersService) {}
 
getOrders(): void {
      this.orderService.getOrders()
      .subscribe(orders => this.orders = orders);
  
}

deleteOrder(id:any):void{
 const res=confirm("Are You sure you want to delete?");
 if(res){
    this.orderService.deleteOrder(id).subscribe(result =>{

    });
 }

}

ngOnInit(): void {
      this.getOrders();
}
}
