import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CrudOrdersService } from 'src/app/services/crud-orders.service';
import { Order } from 'src/app/shared/models/order';

@Component({
  selector: 'app-addorder',
  templateUrl: './addorder.component.html',
  styleUrls: ['./addorder.component.css']
})
export class AddorderComponent {
  orderAddForm!: FormGroup; 

  constructor(private fb:FormBuilder,private orderService: CrudOrdersService) { } 
 
   ngOnInit(): void {
    this.orderAddForm = this.fb.group({ 
      
    });
  } 
  
  addOrder():void{
    if (this.orderAddForm.valid) {
      const formData: Order = this.orderAddForm.value;
    this.orderService.addOrder(formData).subscribe(result => {
      // Handle add success
    });
  }
  }
  
  afficher(){
   // alert("Name:"+this.productAddForm.controls['nameControl'].value+"\nPrix:"+this.productAddForm.controls['prixControl'].value+"\nCategorie:"+this.productAddForm.controls['categorieControl'].value);
  }
 
}
