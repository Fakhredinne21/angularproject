import { Component, OnInit } from '@angular/core';
import { toArray } from 'rxjs';
import { CrudService } from 'src/app/services/crud.service';
import { Produit } from 'src/app/shared/models/produit';

@Component({
  selector: 'app-home-products',
  templateUrl: './home-products.component.html',
  styleUrls: ['./home-products.component.css']
})
export class HomeProductsComponent implements OnInit{
  title = "PRODUITS" ;
  produits !:Produit[] ;
  produit!: Produit;
constructor(private productService:CrudService) {}
details(p:Produit){
  this.produit=p;
}
ngOnInit(): void {
  this.getProducts();
}
getProducts(): void {
      this.productService.getProducts()
      .subscribe(products => this.produits = products);
}

}


