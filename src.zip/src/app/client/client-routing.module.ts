import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClientComponent } from './client.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { OrdersComponent } from './orders/orders.component';
import { AddorderComponent } from './home/addorder.component';
import { ListordersComponent } from './home/listorders.component';

const routes: Routes = [
  {path : '', component : ClientComponent,
  children:[
    {path : 'home', component : HomeComponent},
    {path : 'addorder', component : AddorderComponent},
    {path : 'listorders', component : ListordersComponent},
    {path : 'about', component : AboutComponent}
   
  ]
}
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientRoutingModule { }
