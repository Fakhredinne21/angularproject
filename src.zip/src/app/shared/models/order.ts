import { Client } from "./client";
import { Produit } from "./produit";

export class Order {
    id?: number;
    client?:Client;
    produits?:Produit[];
    price?:number;
    modeLivraison?:string;
    status?:string;
    rate?:string;
constructor(args: Order ) {
this.id = args.id;
this.client = args.client;
this.produits = args.produits;
this.modeLivraison = args.modeLivraison;
this.price = args.price;
this.status=args.status;
this.rate=args.rate;
}
}