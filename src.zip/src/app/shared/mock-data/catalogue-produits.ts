import {Produit} from '../models/produit' ;
export const CATALOGUE:Produit[]=[
    {nom:'HP Victus',prix:'2700dt',categId:'C1',image:'assets/victus.png',description:"-Strorage: 500GB SDD   -RAM: 8GB NVME -Processor: Ryzen 7 5500 H"},
    {nom:'MAC',prix:'7000dt',categId:'C1',image:'assets/mac.png',description:"MAC"},
    {nom:'MSI Kattana',prix:'160dt',image:'assets/msikattana.webp',categId:'C1',description:"MSI Kattana"}
, {nom:'HP Victus',prix:'2700dt',categId:'C1',image:'assets/victus.png',description:"-Strorage: 500GB SDD   -RAM: 8GB NVME -Processor: Ryzen 7 5500 H"},
{nom:'HP Victus',prix:'2700dt',categId:'C1',image:'assets/victus.png',description:"-Strorage: 500GB SDD   -RAM: 8GB NVME -Processor: Ryzen 7 5500 H"}
]

