import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, of } from 'rxjs';
import { Order } from '../shared/models/order';

@Injectable({
  providedIn: 'root'
})
export class CrudOrdersService {
  ordersUrl: string = 'http://localhost:4000/produits';
  httpOptions = {
   headers: new HttpHeaders({ 'Content-Type': 'application/json' })
   };
   constructor(private http: HttpClient) { }
   //read
   getOrders(): Observable<Order[]> {
   return this.http.get<Order[]>(this.ordersUrl)
   .pipe(
   catchError(this.handleError<Order[]>('getProducts', []))
   );
   }
  
   //write
    addOrder(order: Order): Observable<Order> {
      return this.http.post<Order>(this.ordersUrl, order, this.httpOptions)
        .pipe(
          catchError(this.handleError<Order>('addOrder'))
        );
    }
  
    // write (update)
    updateOrder(order: Order): Observable<any> {
      const url = `${this.ordersUrl}/${order.id}`;
      return this.http.put(url, order, this.httpOptions)
        .pipe(
          catchError(this.handleError<any>('updateOrder'))
        );
    }
  
    // write (delete)
    deleteOrder(id: number): Observable<Order> {
      const url = `${this.ordersUrl}/${id}`;
      return this.http.delete<Order>(url, this.httpOptions)
        .pipe(
          catchError(this.handleError<Order>('deleteOrder'))
        );
    }
  
    private handleError<T>(operation = 'operation', result?: T) {
      return (error: any): Observable<T> => {
        console.error(error);
        return of(result as T);
      };
    }
}
